let name = "sadık turan";

const sayHello = ()=> {
    console.log('hello there');
}

sayHello();
