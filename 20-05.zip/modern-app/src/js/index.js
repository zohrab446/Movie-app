// import {sum,mult} from './lib';
// import * as lib from './lib';
import myLib from './lib';
const lib = new myLib();

console.log(lib.sum(1,2,3));
console.log(lib.mult(1,2,3,4));
